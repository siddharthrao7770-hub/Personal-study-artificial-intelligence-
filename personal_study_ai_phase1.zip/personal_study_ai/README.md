# Personal Study AI — Phase 1

A bright, student-friendly Flutter starter app for personalized CBSE Class 10 study discovery.

## Included in Phase 1
- Material 3 app theme
- Home dashboard
- Bottom navigation: Home, Discover, Library, Profile
- Study AI search screen UI with sample prompts
- Starter personalization toggles for CBSE, Class 10 and feedback learning
- No API keys or backend credentials included

## Requirements
- Flutter SDK (stable channel)
- Android Studio or Android SDK
- Android device or emulator

## Generate Android platform files
This starter contains the Flutter app source. From this folder, run:

```bash
flutter create --platforms=android .
```

If Flutter reports that the project already exists, confirm generation of the Android platform folder. Then run:

```bash
flutter pub get
flutter run
```

## Build an APK
```bash
flutter build apk --release
```

APK output:
`build/app/outputs/flutter-apk/app-release.apk`

## Next phases
1. Backend and secure AI API integration
2. Search provider integration and source-linked results
3. Supabase authentication and preference storage
4. Saved resource library and feedback-based ranking

## Security
Never place private API keys in Flutter client code. All secret API credentials must stay on a secure backend.
