import 'package:flutter/material.dart';
import 'screens/app_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PersonalStudyAI());
}

class PersonalStudyAI extends StatelessWidget {
  const PersonalStudyAI({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF5B5CE2);
    return MaterialApp(
      title: 'Personal Study AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.light,
          surface: const Color(0xFFF8F9FF),
        ),
        scaffoldBackgroundColor: const Color(0xFFF8F9FF),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF8F9FF),
          surfaceTintColor: Colors.transparent,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
            side: const BorderSide(color: Color(0xFFE9EAF5)),
          ),
        ),
      ),
      home: const AppShell(),
    );
  }
}
