import 'package:flutter/material.dart';

class DiscoverScreen extends StatelessWidget {
  const DiscoverScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Discover')),
    body: ListView(padding: const EdgeInsets.all(20), children: const [
      Text('Find your next learning resource.', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
      SizedBox(height: 8),
      Text('Personalized web search, notes and question-paper discovery will be added in Phase 3.', style: TextStyle(color: Color(0xFF777895), height: 1.5)),
      SizedBox(height: 22),
      _InfoCard(icon: Icons.picture_as_pdf_rounded, title: 'PDF question banks', subtitle: 'Discover chapter-wise practice material.'),
      _InfoCard(icon: Icons.ondemand_video_rounded, title: 'Video lessons', subtitle: 'Find explanations from learning platforms.'),
      _InfoCard(icon: Icons.fact_check_rounded, title: 'Previous-year papers', subtitle: 'Locate exam papers and answer keys.'),
    ]),
  );
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.title, required this.subtitle});
  final IconData icon; final String title; final String subtitle;
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: ListTile(contentPadding: const EdgeInsets.all(12), leading: CircleAvatar(backgroundColor: const Color(0xFFECEBFF), child: Icon(icon, color: const Color(0xFF5556CE))), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(subtitle)),
  );
}
