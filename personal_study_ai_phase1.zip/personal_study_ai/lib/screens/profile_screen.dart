import 'package:flutter/material.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}
class _ProfileScreenState extends State<ProfileScreen> {
  bool cbse = true;
  bool classTen = true;
  bool rememberFeedback = true;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Personalize your AI')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Help your AI understand what you need.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      const Text('These are starter preferences. They will be stored in your account after backend integration.', style: TextStyle(color: Color(0xFF777895))),
      const SizedBox(height: 20),
      SwitchListTile(value: cbse, onChanged: (v) => setState(() => cbse = v), title: const Text('CBSE curriculum'), subtitle: const Text('Prioritize CBSE learning resources')),
      SwitchListTile(value: classTen, onChanged: (v) => setState(() => classTen = v), title: const Text('Class 10'), subtitle: const Text('Start with Class 10 content')),
      SwitchListTile(value: rememberFeedback, onChanged: (v) => setState(() => rememberFeedback = v), title: const Text('Learn from my feedback'), subtitle: const Text('Use helpful / not helpful feedback to improve recommendations')),
      const SizedBox(height: 14),
      const Text('More preferences such as language, difficulty level, exam goals and preferred resource types will be added next.', style: TextStyle(color: Color(0xFF777895), height: 1.5)),
    ]),
  );
}
