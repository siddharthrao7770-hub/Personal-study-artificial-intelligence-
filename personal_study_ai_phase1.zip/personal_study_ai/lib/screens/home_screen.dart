import 'package:flutter/material.dart';
import '../widgets/section_title.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
        children: [
          Row(
            children: [
              Container(
                width: 46, height: 46,
                decoration: BoxDecoration(color: const Color(0xFFE9E9FF), borderRadius: BorderRadius.circular(15)),
                child: const Icon(Icons.auto_awesome_rounded, color: Color(0xFF5B5CE2), size: 27),
              ),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('PERSONAL STUDY AI', style: TextStyle(fontSize: 11, letterSpacing: 1.2, fontWeight: FontWeight.w800, color: Color(0xFF777895))),
                Text('Your learning space', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: Color(0xFF20213A))),
              ])),
              const CircleAvatar(backgroundColor: Color(0xFFFFE8D8), child: Icon(Icons.person, color: Color(0xFFB76B36))),
            ],
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF6868E8), Color(0xFF8D7BF0)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(26),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('HELLO, LEARNER 👋', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700, letterSpacing: 1)),
              const SizedBox(height: 10),
              const Text('What do you want\nto learn today?', style: TextStyle(color: Colors.white, fontSize: 26, height: 1.15, fontWeight: FontWeight.w800)),
              const SizedBox(height: 17),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF5556CE)),
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StudySearchPage())),
                icon: const Icon(Icons.search),
                label: const Text('Ask your study AI'),
              ),
            ]),
          ),
          const SizedBox(height: 25),
          const SectionTitle('Your study space'),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _QuickCard(icon: Icons.menu_book_rounded, title: 'CBSE Class 10', subtitle: 'Your current track', color: const Color(0xFFE8F4FF))),
            const SizedBox(width: 12),
            Expanded(child: _QuickCard(icon: Icons.auto_graph_rounded, title: 'Study progress', subtitle: 'Tracker coming soon', color: const Color(0xFFFFF0E4))),
          ]),
          const SizedBox(height: 24),
          const SectionTitle('Explore subjects'),
          const SizedBox(height: 12),
          const _SubjectTile(name: 'Mathematics', detail: 'Concepts, examples and practice', icon: Icons.calculate_rounded, color: Color(0xFFECEBFF)),
          const _SubjectTile(name: 'Science', detail: 'Physics, Chemistry and Biology', icon: Icons.science_rounded, color: Color(0xFFE5F7EF)),
          const _SubjectTile(name: 'Social Science', detail: 'History, Geography, Civics and Economics', icon: Icons.public_rounded, color: Color(0xFFFFF1E5)),
          const _SubjectTile(name: 'English', detail: 'Literature, grammar and writing', icon: Icons.edit_note_rounded, color: Color(0xFFFFEAF0)),
          const SizedBox(height: 12),
          const Text('Phase 1 preview • Search and AI features will be connected in the next development phase.', style: TextStyle(color: Color(0xFF85869D), fontSize: 12, height: 1.4)),
        ],
      ),
    );
  }
}

class _QuickCard extends StatelessWidget {
  const _QuickCard({required this.icon, required this.title, required this.subtitle, required this.color});
  final IconData icon; final String title; final String subtitle; final Color color;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE9EAF5))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      CircleAvatar(backgroundColor: color, child: Icon(icon, color: const Color(0xFF5556CE))),
      const SizedBox(height: 12),
      Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF292A43))),
      const SizedBox(height: 4),
      Text(subtitle, style: const TextStyle(fontSize: 11, color: Color(0xFF85869D))),
    ]),
  );
}

class _SubjectTile extends StatelessWidget {
  const _SubjectTile({required this.name, required this.detail, required this.icon, required this.color});
  final String name; final String detail; final IconData icon; final Color color;
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 9),
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17), border: Border.all(color: const Color(0xFFE9EAF5))),
    child: Row(children: [
      CircleAvatar(backgroundColor: color, child: Icon(icon, color: const Color(0xFF5556CE))),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
        Text(detail, style: const TextStyle(fontSize: 11, color: Color(0xFF85869D))),
      ])),
      const Icon(Icons.chevron_right_rounded, color: Color(0xFF999AAF)),
    ]),
  );
}

class StudySearchPage extends StatefulWidget {
  const StudySearchPage({super.key});
  @override
  State<StudySearchPage> createState() => _StudySearchPageState();
}
class _StudySearchPageState extends State<StudySearchPage> {
  final controller = TextEditingController();
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Ask your study AI')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('What are you looking for?', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('Search for a chapter, concept, PDF or question paper.', style: TextStyle(color: Color(0xFF777895))),
        const SizedBox(height: 18),
        TextField(controller: controller, maxLines: 3, decoration: InputDecoration(hintText: 'e.g. Find CBSE Class 10 electricity notes...', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFE5E6F0))), suffixIcon: IconButton(icon: const Icon(Icons.arrow_upward_rounded), onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('AI search will be connected in Phase 2.')))))),
        const SizedBox(height: 16),
        const Text('Try asking', style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        for (final suggestion in ['Find notes for electricity', 'Explain quadratic equations simply', 'Find previous-year question papers'])
          Padding(padding: const EdgeInsets.only(bottom: 8), child: ActionChip(label: Text(suggestion), onPressed: () => setState(() => controller.text = suggestion))),
      ]),
    ),
  );
}
