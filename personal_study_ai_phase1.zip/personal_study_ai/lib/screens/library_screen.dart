import 'package:flutter/material.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My library')),
    body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: const [
      CircleAvatar(radius: 34, backgroundColor: Color(0xFFECEBFF), child: Icon(Icons.bookmark_outline_rounded, size: 34, color: Color(0xFF5556CE))),
      SizedBox(height: 16),
      Text('Your saved resources will live here', textAlign: TextAlign.center, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
      SizedBox(height: 8),
      Text('Save useful notes, PDFs and learning links when discovery is connected.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF777895))),
    ]))),
  );
}
